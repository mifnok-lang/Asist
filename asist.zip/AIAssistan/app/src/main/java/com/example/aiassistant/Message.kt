package com.example.aiassistant

data class Message(
    val text: String,
    val isUser: Boolean
)
