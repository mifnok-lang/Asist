package com.example.aiassistant

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aiassistant.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val messages = mutableListOf<Message>()
    private lateinit var adapter: ChatAdapter
    private lateinit var brain: AgentBrain

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = AppDatabase.get(this)
        val repo = MemoryRepository(db.memoryDao())
        val web = WebBrowserTool()
        brain = AgentBrain(repo, web)

        adapter = ChatAdapter(messages)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.btnSend.setOnClickListener {
            val input = binding.etInput.text.toString().trim()
            if (input.isEmpty()) return@setOnClickListener

            binding.etInput.text?.clear()
            adapter.add(Message(input, true))
            binding.recyclerView.scrollToPosition(messages.size - 1)

            lifecycleScope.launch {
                val answer = withContext(Dispatchers.IO) {
                    brain.answer(input)
                }
                adapter.add(Message(answer, false))
                binding.recyclerView.scrollToPosition(messages.size - 1)
            }
        }
    }
}
