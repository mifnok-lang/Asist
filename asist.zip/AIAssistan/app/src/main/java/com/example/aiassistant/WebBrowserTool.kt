package com.example.aiassistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URLEncoder

class WebBrowserTool {
    private val client = OkHttpClient()

    fun search(query: String): String {
        val url = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8")
        return fetch(url)
    }

    fun open(url: String): String {
        return fetch(url)
    }

    fun extractText(html: String): String {
        val doc = Jsoup.parse(html)
        doc.select("script,style,noscript").remove()
        return doc.text().take(12000)
    }

    fun extractLinks(html: String): List<String> {
        val doc = Jsoup.parse(html)
        return doc.select("a[href]")
            .mapNotNull { it.absUrl("href").ifBlank { it.attr("href") } }
            .distinct()
            .take(20)
    }

    private fun fetch(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0")
            .build()

        client.newCall(request).execute().use { response ->
            return response.body?.string().orEmpty()
        }
    }
}
