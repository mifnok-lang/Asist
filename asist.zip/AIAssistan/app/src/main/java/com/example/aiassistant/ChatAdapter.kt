package com.example.aiassistant

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aiassistant.databinding.ItemMessageBinding

class ChatAdapter(private val items: MutableList<Message>) :
    RecyclerView.Adapter<ChatAdapter.VH>() {

    class VH(val binding: ItemMessageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = items[position]
        holder.binding.tvMessage.text = msg.text
        holder.binding.tvMessage.textAlignment =
            if (msg.isUser) android.view.View.TEXT_ALIGNMENT_VIEW_END
            else android.view.View.TEXT_ALIGNMENT_VIEW_START
    }

    override fun getItemCount() = items.size

    fun add(message: Message) {
        items.add(message)
        notifyItemInserted(items.size - 1)
    }
}
