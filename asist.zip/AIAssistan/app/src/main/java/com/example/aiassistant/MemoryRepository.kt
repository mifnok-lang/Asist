package com.example.aiassistant

class MemoryRepository(private val dao: MemoryDao) {

    private fun normalize(text: String) = text.trim().lowercase()

    suspend fun get(question: String): String? {
        return dao.get(normalize(question))?.answer
    }

    suspend fun save(question: String, answer: String) {
        dao.insert(
            MemoryEntity(
                question = normalize(question),
                answer = answer
            )
        )
    }
}
