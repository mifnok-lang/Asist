package com.example.aiassistant

class AgentBrain(
    private val memoryRepository: MemoryRepository,
    private val webBrowserTool: WebBrowserTool
) {
    suspend fun answer(question: String): String {
        val cached = memoryRepository.get(question)
        if (cached != null) return cached

        val searchHtml = webBrowserTool.search(question)
        val text = webBrowserTool.extractText(searchHtml)

        val answer = if (text.isNotBlank()) {
            "Найдено в интернете:\n\n${text.take(2500)}"
        } else {
            "Ничего не найдено."
        }

        memoryRepository.save(question, answer)
        return answer
    }
}
